﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Digit.Console.Core;
using Microsoft.Extensions.Configuration;

namespace Digit.Console.Infrastructure
{
    public class ConfigurationSettingsService : IConfigurationSettingsService
    {
        private readonly IConfiguration _configuration;
        public ConfigurationSettingsService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<List<IConfigurationSection>> GetConfigurationSettings()
        {
            return await Task.FromResult(_configuration.GetChildren().ToList());
        }
    }
}
