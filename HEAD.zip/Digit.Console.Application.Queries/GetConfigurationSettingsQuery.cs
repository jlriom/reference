﻿using System.Collections.Generic;
using Common.Application.Cqs.Contracts;
using Digit.Console.Application.Queries.Dtos;

namespace Digit.Console.Application.Queries
{
   public class GetConfigurationSettingsQuery: IQuery<IEnumerable<ConfigurationSettingsDto>>
   {
   }
}
