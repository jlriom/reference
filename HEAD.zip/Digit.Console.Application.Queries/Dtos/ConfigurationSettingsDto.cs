﻿namespace Digit.Console.Application.Queries.Dtos
{
    public class ConfigurationSettingsDto 
    {
        public string Key { get; }
        public string Path { get; }
        public string Value { get; }

        public ConfigurationSettingsDto(string key, string path, string value)
        {
            Key = key;
            Path = path;
            Value = value;
        }
    }
}
