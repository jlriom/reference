﻿using MediatR;

namespace Common.Application.Cqs.Contracts
{
   public interface IEvent : INotification
   {
   }
}
