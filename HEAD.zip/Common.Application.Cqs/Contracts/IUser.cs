﻿namespace Common.Application.Cqs.Contracts
{
   public interface IUser
   {
      string Id { get; }
   }
}
