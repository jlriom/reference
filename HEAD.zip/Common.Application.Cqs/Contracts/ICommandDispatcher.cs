﻿using System.Threading;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;

namespace Common.Application.Cqs.Contracts
{
   public interface ICommandDispatcher : IBus
   {
      Task<Result> Dispatch(ICommand command, CancellationToken cancellationToken = default);
   }
}
