﻿using System;
using Common.Application.Cqs.Contracts;

namespace Common.Application.Cqs.Implementation
{
   public class User : IUser
   {
      public string Id { get; }

      public User(): this(String.Empty)
      {
      }

      public User(string id)
      {
          Id = id;
      }
   }
}
