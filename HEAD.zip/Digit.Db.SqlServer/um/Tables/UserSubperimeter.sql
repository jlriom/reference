﻿CREATE TABLE [um].[UserSubperimeter] (
    [UserId]             UNIQUEIDENTIFIER NOT NULL,
    [SubperimeterId] INT              NOT NULL,
    CONSTRAINT [PK_UserSubperimeter] PRIMARY KEY CLUSTERED ([UserId] ASC, [SubperimeterId] ASC),
    CONSTRAINT [FK_UserSubperimeter_SubperimeterId] FOREIGN KEY ([SubperimeterId]) REFERENCES [uw].[Subperimeter] ([Id]),
    CONSTRAINT [FK_UserSubperimeter_UserId] FOREIGN KEY ([UserId]) REFERENCES [um].[User] ([Id]),
    CONSTRAINT [UQ_UserSubperimeter] UNIQUE NONCLUSTERED ([UserId] ASC, [SubperimeterId] ASC)
);

