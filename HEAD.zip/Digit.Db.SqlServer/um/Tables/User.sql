﻿CREATE TABLE [um].[User] (
    [Id]             UNIQUEIDENTIFIER NOT NULL,
    [CreatedOn]      DATETIME         CONSTRAINT [DF_User_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]      VARCHAR (256)    NOT NULL,
    [UpdatedOn]      DATETIME         CONSTRAINT [DF_User_UpdatedOn] DEFAULT (getdate()) NOT NULL,
    [UpdatedBy]      VARCHAR (256)    NOT NULL,
    [StatusComments] VARCHAR (2000)   NULL,
    [Email]          VARCHAR (300)    NOT NULL,
    [Name] VARCHAR(300) NOT NULL, 
    [LastName] VARCHAR(300) NOT NULL, 
    CONSTRAINT [PK_User_1] PRIMARY KEY CLUSTERED ([Id] ASC),
);

