﻿CREATE TABLE [um].[UserRfUserRoleType] (
    [UserId]           UNIQUEIDENTIFIER NOT NULL,
    [RfUserRoleTypeId] INT              NOT NULL,
    CONSTRAINT [PK_UserRfUserRoleType_1] PRIMARY KEY CLUSTERED ([UserId] ASC, [RfUserRoleTypeId] ASC),
    CONSTRAINT [FK_UserRfUserRoleType_RfUserRoleType] FOREIGN KEY ([RfUserRoleTypeId]) REFERENCES [referential].[RfUserRoleType] ([Id]),
    CONSTRAINT [FK_UserRfUserRoleType_User] FOREIGN KEY ([UserId]) REFERENCES [um].[User] ([Id]) ON DELETE CASCADE
);

