﻿CREATE TABLE [um].[UserNonDisclosureAgreement] (
    [Id]                       UNIQUEIDENTIFIER NOT NULL,
    [UserId]                   UNIQUEIDENTIFIER NOT NULL,
    [NonDisclosureAgreementId] UNIQUEIDENTIFIER NOT NULL,
    [Year]                     INT              NOT NULL,
    [AcceptationDateTime]      DATETIME         NULL,
    [LastestRejectionDateTime] DATETIME         NULL,
    CONSTRAINT [PK_UserNonDisclosureAgreement] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_UserNonDisclodureAgreement_User] FOREIGN KEY ([UserId]) REFERENCES [um].[User] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_UserNonDisclosureAgreement_NonDisclosureAgreement] FOREIGN KEY ([NonDisclosureAgreementId]) REFERENCES [referential].[NonDisclosureAgreement] ([Id])
);

