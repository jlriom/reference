﻿CREATE TABLE [um].[UserEntity] (
    [UserId]             UNIQUEIDENTIFIER NOT NULL,
    [AxaEntityCompanyId] INT              NOT NULL,
    CONSTRAINT [PK_UserEntity] PRIMARY KEY CLUSTERED ([UserId] ASC),
    CONSTRAINT [FK_UserEntity_AxaEntityCompany] FOREIGN KEY ([AxaEntityCompanyId]) REFERENCES [referential].[AxaEntityCompany] ([Id]),
    CONSTRAINT [FK_UserEntity_User] FOREIGN KEY ([UserId]) REFERENCES [um].[User] ([Id])
);

