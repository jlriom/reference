﻿CREATE SCHEMA [referential]
    AUTHORIZATION [dbo];

