﻿CREATE TABLE [referential].[NonDisclosureAgreement] (
    [Id]              UNIQUEIDENTIFIER NOT NULL,
    [CreationDateTme] DATETIME         NOT NULL,
    [AgreementText]   NVARCHAR (MAX)   NOT NULL,
    CONSTRAINT [PK_NonDisclosureAgreement] PRIMARY KEY CLUSTERED ([Id] ASC)
);

