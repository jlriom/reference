﻿CREATE TABLE [referential].[RfGuidelineStatus] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_RfGuidelineStatus] PRIMARY KEY CLUSTERED ([Id] ASC)
);

