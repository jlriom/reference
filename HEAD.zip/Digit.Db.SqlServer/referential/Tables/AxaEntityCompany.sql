﻿CREATE TABLE [referential].[AxaEntityCompany] (
    [Id]   INT           NOT NULL,
    [Name] VARCHAR (300) NOT NULL,
    CONSTRAINT [PK_AxaEntityCompany] PRIMARY KEY CLUSTERED ([Id] ASC)
);

