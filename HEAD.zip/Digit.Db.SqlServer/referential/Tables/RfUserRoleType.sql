﻿CREATE TABLE [referential].[RfUserRoleType] (
    [Id]   INT          NOT NULL,
    [Name] VARCHAR (15) NOT NULL,
    CONSTRAINT [PK_RfUserRoleType] PRIMARY KEY CLUSTERED ([Id] ASC)
);

