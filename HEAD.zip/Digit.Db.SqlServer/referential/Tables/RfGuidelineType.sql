﻿CREATE TABLE [referential].[RfGuidelineType] (
    [Id]   INT            NOT NULL,
    [Name] NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_RfGuidelineType] PRIMARY KEY CLUSTERED ([Id] ASC)
);

