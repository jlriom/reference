﻿CREATE TABLE [uw].[Guideline] (
    [Id]                  UNIQUEIDENTIFIER CONSTRAINT [DF__Guideline__Id__24927208] DEFAULT (newid()) NOT NULL,
    [Name]                VARCHAR (256)    NOT NULL,
    [UwYear]              INT              NOT NULL,
    [RfGuidelineTypeId]   INT              NOT NULL,
    [RfGuidelineStatusId] INT              NOT NULL,
    [DocumentUrl]         NVARCHAR (3000)  NOT NULL,
    [DocumentName]        NVARCHAR (255)   NOT NULL,
    [DocumentUploadedBy]  NVARCHAR (50)    NOT NULL,
    [DocumentUploadedOn]  DATETIME         NOT NULL,
    [CreatedOn]           DATETIME         CONSTRAINT [DF__Guideline__Creat__25869641] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]           VARCHAR (256)    NOT NULL,
    [UpdatedOn]           DATETIME         CONSTRAINT [DF__Guideline__Updat__267ABA7A] DEFAULT (getdate()) NOT NULL,
    [UpdatedBy]           VARCHAR (256)    NOT NULL,
    CONSTRAINT [PK__Guidelin__3214EC076EAC4CBA] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Guideline_RfGuidelineStatus] FOREIGN KEY ([RfGuidelineStatusId]) REFERENCES [referential].[RfGuidelineStatus] ([Id]),
    CONSTRAINT [FK_Guideline_RfGuidelineType] FOREIGN KEY ([RfGuidelineTypeId]) REFERENCES [referential].[RfGuidelineType] ([Id])
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Guideline_Name]
    ON [uw].[Guideline]([Name] ASC);

