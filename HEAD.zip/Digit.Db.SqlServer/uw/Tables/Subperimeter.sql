﻿CREATE TABLE [uw].[Subperimeter] (
    [Id]       INT            NOT NULL,
    [Name]     NVARCHAR (255) NOT NULL,
    [IsHidden] BIT            CONSTRAINT [DF_Subperimeter_IsHidden] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_Subperimeter] PRIMARY KEY CLUSTERED ([Id] ASC)
);

