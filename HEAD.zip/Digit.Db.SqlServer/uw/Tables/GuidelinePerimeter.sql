﻿CREATE TABLE [uw].[GuidelinePerimeter] (
    [GuidelineId]        UNIQUEIDENTIFIER NOT NULL,
    [SubperimeterId] INT              NOT NULL,
    PRIMARY KEY CLUSTERED ([GuidelineId] ASC, [SubperimeterId] ASC),
    CONSTRAINT [FK_GuidelinePerimeter_FK1] FOREIGN KEY ([GuidelineId]) REFERENCES [uw].[Guideline] ([Id]) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT [FK_GuidelinePerimeters_FK2] FOREIGN KEY ([SubperimeterId]) REFERENCES [uw].[Subperimeter] ([Id]) ON DELETE CASCADE ON UPDATE CASCADE
);

