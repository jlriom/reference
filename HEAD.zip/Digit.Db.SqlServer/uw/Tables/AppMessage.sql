﻿CREATE TABLE [uw].[AppMessage] (
    [Id]               INT           NOT NULL,
    [CreationDateTime] DATETIME      NULL,
    [TextMessage]      VARCHAR (MAX) NULL,
    CONSTRAINT [PK_AppMessage] PRIMARY KEY CLUSTERED ([Id] ASC)
);

