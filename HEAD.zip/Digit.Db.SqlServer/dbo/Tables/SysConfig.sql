﻿CREATE TABLE [dbo].[SysConfig]
(
	[Key] NVARCHAR(200) NOT NULL PRIMARY KEY, 
    [Value] NVARCHAR(1000) NOT NULL, 
    [Module] NVARCHAR(200) NULL 
)
