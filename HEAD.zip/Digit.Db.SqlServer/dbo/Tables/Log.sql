﻿CREATE TABLE [dbo].[Log] (
    [Id]                    UNIQUEIDENTIFIER NOT NULL,
    [ActionUserEmail]       VARCHAR (300)    NOT NULL,
    [ActionUserId]          UNIQUEIDENTIFIER NOT NULL,
    [TypeOfAccount]         VARCHAR (300)    NOT NULL,
    [ActionName]            VARCHAR (300)    NOT NULL,
    [ActionDate]            DATETIME         NOT NULL,
    [IsSuccess]             BIT              NOT NULL,
    [ErrorMessage]          VARCHAR (2000)   NULL,
    [AffectedComponents]    VARCHAR (2000)   NOT NULL,
    [AffectedGuidelineName] VARCHAR (300)    NULL,
    [AffectedGuidelineId]   UNIQUEIDENTIFIER NULL,
    [AffectedUserEmail]     VARCHAR (300)    NULL,
    [AffectedUserId]        UNIQUEIDENTIFIER NULL,
    [CommandId]             UNIQUEIDENTIFIER NOT NULL,
    [TechnicalDetails]      VARCHAR (5000)   NULL,
    CONSTRAINT [PK_Logs] PRIMARY KEY CLUSTERED ([Id] ASC)
);

