﻿using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace Digit.Shared.Data
{
    public partial class DigitContext
    {
        private const string Sql = "select [key], value from dbo.SysConfig where Module = '{0}' or Module is null ";

        public static Dictionary<string, string> GetConfigurationSettings(string connectionString, string module)
        {
            var settings = new Dictionary<string, string>();

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand(
                    string.Format(Sql, module), conn))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            settings.Add(reader.GetString(0), reader.GetString(1));
                        }
                        reader.Close();
                    }
                }
                conn.Close();
            }

            return settings;
        }
    }
}
