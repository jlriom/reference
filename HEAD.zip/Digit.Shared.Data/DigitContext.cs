﻿using Digit.Shared.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Digit.Shared.Data
{
    public partial class DigitContext : DbContext
    {
        public DigitContext()
        {
            
        }

        public DigitContext(DbContextOptions<DigitContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AppMessage> AppMessage { get; set; }
        public virtual DbSet<AxaEntityCompany> AxaEntityCompany { get; set; }
        public virtual DbSet<Guideline> Guideline { get; set; }
        public virtual DbSet<GuidelinePerimeter> GuidelinePerimeter { get; set; }
        public virtual DbSet<Log> Log { get; set; }
        public virtual DbSet<NonDisclosureAgreement> NonDisclosureAgreement { get; set; }
        public virtual DbSet<RfGuidelineStatus> RfGuidelineStatus { get; set; }
        public virtual DbSet<RfGuidelineType> RfGuidelineType { get; set; }
        public virtual DbSet<RfUserRoleType> RfUserRoleType { get; set; }
        public virtual DbSet<Subperimeter> Subperimeter { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserEntity> UserEntity { get; set; }
        public virtual DbSet<UserNonDisclosureAgreement> UserNonDisclosureAgreement { get; set; }
        public virtual DbSet<UserRfUserRoleType> UserRfUserRoleType { get; set; }
        public virtual DbSet<UserSubperimeter> UserSubperimeter { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppMessage>(entity =>
            {
                entity.ToTable("AppMessage", "uw");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreationDateTime).HasColumnType("datetime");

                entity.Property(e => e.TextMessage).IsUnicode(false);
            });

            modelBuilder.Entity<AxaEntityCompany>(entity =>
            {
                entity.ToTable("AxaEntityCompany", "referential");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Guideline>(entity =>
            {
                entity.ToTable("Guideline", "uw");

                entity.HasIndex(e => e.Name)
                    .IsUnique();

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.DocumentUploadedBy)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.DocumentUploadedOn).HasColumnType("datetime");

                entity.Property(e => e.DocumentUrl)
                    .IsRequired()
                    .HasMaxLength(3000);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.RfGuidelineStatus)
                    .WithMany(p => p.Guideline)
                    .HasForeignKey(d => d.RfGuidelineStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Guideline_RfGuidelineStatus");

                entity.HasOne(d => d.RfGuidelineType)
                    .WithMany(p => p.Guideline)
                    .HasForeignKey(d => d.RfGuidelineTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Guideline_RfGuidelineType");
            });

            modelBuilder.Entity<GuidelinePerimeter>(entity =>
            {
                entity.HasKey(e => new { e.GuidelineId, e.SubperimeterId })
                    .HasName("PK__Guidelin__BB76638EA60891A2");

                entity.ToTable("GuidelinePerimeter", "uw");

                entity.HasOne(d => d.Guideline)
                    .WithMany(p => p.GuidelinePerimeter)
                    .HasForeignKey(d => d.GuidelineId)
                    .HasConstraintName("FK_GuidelinePerimeter_FK1");

                entity.HasOne(d => d.Subperimeter)
                    .WithMany(p => p.GuidelinePerimeter)
                    .HasForeignKey(d => d.SubperimeterId)
                    .HasConstraintName("FK_GuidelinePerimeters_FK2");
            });

            modelBuilder.Entity<Log>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ActionDate).HasColumnType("datetime");

                entity.Property(e => e.ActionName)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.ActionUserEmail)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.AffectedComponents)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.AffectedGuidelineName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.AffectedUserEmail)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorMessage)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.TechnicalDetails)
                    .HasMaxLength(5000)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfAccount)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NonDisclosureAgreement>(entity =>
            {
                entity.ToTable("NonDisclosureAgreement", "referential");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AgreementText).IsRequired();

                entity.Property(e => e.CreationDateTme).HasColumnType("datetime");
            });

            modelBuilder.Entity<RfGuidelineStatus>(entity =>
            {
                entity.ToTable("RfGuidelineStatus", "referential");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<RfGuidelineType>(entity =>
            {
                entity.ToTable("RfGuidelineType", "referential");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<RfUserRoleType>(entity =>
            {
                entity.ToTable("RfUserRoleType", "referential");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Subperimeter>(entity =>
            {
                entity.ToTable("Subperimeter", "uw");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User", "um");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.StatusComments)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<UserEntity>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("UserEntity", "um");

                entity.Property(e => e.UserId).ValueGeneratedNever();

                entity.HasOne(d => d.AxaEntityCompany)
                    .WithMany(p => p.UserEntity)
                    .HasForeignKey(d => d.AxaEntityCompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserEntity_AxaEntityCompany");

                entity.HasOne(d => d.User)
                    .WithOne(p => p.UserEntity)
                    .HasForeignKey<UserEntity>(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserEntity_User");
            });

            modelBuilder.Entity<UserNonDisclosureAgreement>(entity =>
            {
                entity.ToTable("UserNonDisclosureAgreement", "um");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AcceptationDateTime).HasColumnType("datetime");

                entity.Property(e => e.LastestRejectionDateTime).HasColumnType("datetime");

                entity.HasOne(d => d.NonDisclosureAgreement)
                    .WithMany(p => p.UserNonDisclosureAgreement)
                    .HasForeignKey(d => d.NonDisclosureAgreementId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserNonDisclosureAgreement_NonDisclosureAgreement");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserNonDisclosureAgreement)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK_UserNonDisclodureAgreement_User");
            });

            modelBuilder.Entity<UserRfUserRoleType>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RfUserRoleTypeId })
                    .HasName("PK_UserRfUserRoleType_1");

                entity.ToTable("UserRfUserRoleType", "um");

                entity.HasOne(d => d.RfUserRoleType)
                    .WithMany(p => p.UserRfUserRoleType)
                    .HasForeignKey(d => d.RfUserRoleTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserRfUserRoleType_RfUserRoleType");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserRfUserRoleType)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK_UserRfUserRoleType_User");
            });

            modelBuilder.Entity<UserSubperimeter>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.SubperimeterId });

                entity.ToTable("UserSubperimeter", "um");

                entity.HasIndex(e => new { e.UserId, e.SubperimeterId })
                    .HasName("UQ_UserSubperimeter")
                    .IsUnique();

                entity.HasOne(d => d.Subperimeter)
                    .WithMany(p => p.UserSubperimeter)
                    .HasForeignKey(d => d.SubperimeterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserSubperimeter_SubperimeterId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserSubperimeter)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserSubperimeter_UserId");
            });
        }
     }
}
