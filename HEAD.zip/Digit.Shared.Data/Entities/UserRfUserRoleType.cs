﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class UserRfUserRoleType
    {
        public Guid UserId { get; set; }
        public int RfUserRoleTypeId { get; set; }

        public virtual RfUserRoleType RfUserRoleType { get; set; }
        public virtual User User { get; set; }
    }
}
