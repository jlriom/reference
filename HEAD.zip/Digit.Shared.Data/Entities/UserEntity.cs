﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class UserEntity
    {
        public Guid UserId { get; set; }
        public int AxaEntityCompanyId { get; set; }

        public virtual AxaEntityCompany AxaEntityCompany { get; set; }
        public virtual User User { get; set; }
    }
}
