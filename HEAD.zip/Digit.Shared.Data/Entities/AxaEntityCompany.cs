﻿using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class AxaEntityCompany
    {
        public AxaEntityCompany()
        {
            UserEntity = new HashSet<UserEntity>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<UserEntity> UserEntity { get; set; }
    }
}
