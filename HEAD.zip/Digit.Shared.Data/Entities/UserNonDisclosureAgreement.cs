﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class UserNonDisclosureAgreement
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public Guid NonDisclosureAgreementId { get; set; }
        public int Year { get; set; }
        public DateTime? AcceptationDateTime { get; set; }
        public DateTime? LastestRejectionDateTime { get; set; }

        public virtual NonDisclosureAgreement NonDisclosureAgreement { get; set; }
        public virtual User User { get; set; }
    }
}
