﻿using System;
using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class Guideline
    {
        public Guideline()
        {
            GuidelinePerimeter = new HashSet<GuidelinePerimeter>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public int UwYear { get; set; }
        public int RfGuidelineTypeId { get; set; }
        public int RfGuidelineStatusId { get; set; }
        public string DocumentUrl { get; set; }
        public string DocumentName { get; set; }
        public string DocumentUploadedBy { get; set; }
        public DateTime DocumentUploadedOn { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }

        public virtual RfGuidelineStatus RfGuidelineStatus { get; set; }
        public virtual RfGuidelineType RfGuidelineType { get; set; }
        public virtual ICollection<GuidelinePerimeter> GuidelinePerimeter { get; set; }
    }
}
