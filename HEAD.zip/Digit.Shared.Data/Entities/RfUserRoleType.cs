﻿using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class RfUserRoleType
    {
        public RfUserRoleType()
        {
            UserRfUserRoleType = new HashSet<UserRfUserRoleType>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<UserRfUserRoleType> UserRfUserRoleType { get; set; }
    }
}
