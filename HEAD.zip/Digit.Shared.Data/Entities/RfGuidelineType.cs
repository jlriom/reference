﻿using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class RfGuidelineType
    {
        public RfGuidelineType()
        {
            Guideline = new HashSet<Guideline>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Guideline> Guideline { get; set; }
    }
}
