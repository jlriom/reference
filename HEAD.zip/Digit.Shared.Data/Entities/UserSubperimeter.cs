﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class UserSubperimeter
    {
        public Guid UserId { get; set; }
        public int SubperimeterId { get; set; }

        public virtual Subperimeter Subperimeter { get; set; }
        public virtual User User { get; set; }
    }
}
