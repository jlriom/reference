﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class GuidelinePerimeter
    {
        public Guid GuidelineId { get; set; }
        public int SubperimeterId { get; set; }

        public virtual Guideline Guideline { get; set; }
        public virtual Subperimeter Subperimeter { get; set; }
    }
}
