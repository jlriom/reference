﻿using System;
using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class NonDisclosureAgreement
    {
        public NonDisclosureAgreement()
        {
            UserNonDisclosureAgreement = new HashSet<UserNonDisclosureAgreement>();
        }

        public Guid Id { get; set; }
        public DateTime CreationDateTme { get; set; }
        public string AgreementText { get; set; }

        public virtual ICollection<UserNonDisclosureAgreement> UserNonDisclosureAgreement { get; set; }
    }
}
