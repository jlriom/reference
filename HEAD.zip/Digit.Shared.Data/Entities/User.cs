﻿using System;
using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class User
    {
        public User()
        {
            UserNonDisclosureAgreement = new HashSet<UserNonDisclosureAgreement>();
            UserRfUserRoleType = new HashSet<UserRfUserRoleType>();
            UserSubperimeter = new HashSet<UserSubperimeter>();
        }

        public Guid Id { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string StatusComments { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }

        public virtual UserEntity UserEntity { get; set; }
        public virtual ICollection<UserNonDisclosureAgreement> UserNonDisclosureAgreement { get; set; }
        public virtual ICollection<UserRfUserRoleType> UserRfUserRoleType { get; set; }
        public virtual ICollection<UserSubperimeter> UserSubperimeter { get; set; }
    }
}
