﻿using System.Collections.Generic;

namespace Digit.Shared.Data.Entities
{
    public partial class Subperimeter
    {
        public Subperimeter()
        {
            GuidelinePerimeter = new HashSet<GuidelinePerimeter>();
            UserSubperimeter = new HashSet<UserSubperimeter>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsHidden { get; set; }

        public virtual ICollection<GuidelinePerimeter> GuidelinePerimeter { get; set; }
        public virtual ICollection<UserSubperimeter> UserSubperimeter { get; set; }
    }
}
