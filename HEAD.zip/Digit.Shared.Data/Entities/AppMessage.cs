﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class AppMessage
    {
        public int Id { get; set; }
        public DateTime? CreationDateTime { get; set; }
        public string TextMessage { get; set; }
    }
}
