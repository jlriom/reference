﻿using System;

namespace Digit.Shared.Data.Entities
{
    public partial class Log
    {
        public Guid Id { get; set; }
        public string ActionUserEmail { get; set; }
        public Guid ActionUserId { get; set; }
        public string TypeOfAccount { get; set; }
        public string ActionName { get; set; }
        public DateTime ActionDate { get; set; }
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string AffectedComponents { get; set; }
        public string AffectedGuidelineName { get; set; }
        public Guid? AffectedGuidelineId { get; set; }
        public string AffectedUserEmail { get; set; }
        public Guid? AffectedUserId { get; set; }
        public Guid CommandId { get; set; }
        public string TechnicalDetails { get; set; }
    }
}
