﻿using AutoMapper;
using Common.Application.Cqs.Contracts;
using Common.Application.Cqs.Implementation;
using Common.Application.Exceptions;
using Digit.Console.Application.Queries;
using Digit.Console.Application.Queries.Dtos;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Digit.Console.Core;

namespace Digit.Console.Application.QueryHandlers
{
    public class ConfigurationSettingsHandler : QueryHandler<GetConfigurationSettingsQuery, IEnumerable<ConfigurationSettingsDto>>
   {
        private readonly IConfigurationSettingsService _configurationSettingsService;

        public ConfigurationSettingsHandler(
          IQueryDispatcher bus, 
          IMapper mapper, 
          ILogger<GetConfigurationSettingsQuery> logger, 
          IConfigurationSettingsService configurationSettingsService) : base(bus, mapper, logger)
        {
            _configurationSettingsService = configurationSettingsService;
        }

      protected override async Task<IEnumerable<ConfigurationSettingsDto>> HandleEx(GetConfigurationSettingsQuery query, CancellationToken cancellationToken = default)
      {
          var settings = await _configurationSettingsService.GetConfigurationSettings();

            //var habitant = await habitantReadOnlyRepository.GetSingleAsync(query.Id);
            //if (habitant.HasValue)
            //   return Mapper.Map<HabitantViewModel> (habitant.Value);

            throw new NotFoundException("Habitant not found");
      }
   }
}
