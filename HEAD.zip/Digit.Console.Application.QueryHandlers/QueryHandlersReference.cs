﻿namespace Digit.Console.Application.QueryHandlers
{
    public class QueryHandlersReference
    {
    }
}
