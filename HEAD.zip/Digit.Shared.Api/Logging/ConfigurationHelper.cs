﻿using Digit.Shared.Api.Configuration;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace Digit.Shared.Api.Logging
{
    public static class ConfigurationHelper
    {
        public static IConfigurationRoot GetConfiguration()
        {

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory());

            builder.AddJsonFile(Constants.ConfigFileName, optional: false, reloadOnChange: true);

            builder.AddEnvironmentVariables();
            return builder.Build();
        }
    }
}
