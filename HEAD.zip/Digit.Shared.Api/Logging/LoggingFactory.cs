﻿using Digit.Shared.Api.Configuration;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Core;

namespace Digit.Shared.Api.Logging
{
    public class LoggingFactory
    {
        public Logger Create()
        {

            var config = ConfigurationHelper.GetConfiguration();
 
            var telemetryConfiguration = TelemetryConfiguration.CreateDefault();

            telemetryConfiguration.InstrumentationKey = config.GetValue<string>(ConfigurationKeys.ApplicationInsightsInstrumentationKey);

            return new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .Enrich.WithMachineName()
                .Enrich.WithProcessId()
                .Enrich.FromLogContext()
                .WriteTo.ApplicationInsights(telemetryConfiguration, TelemetryConverter.Traces)
                .WriteTo.Console()
                .CreateLogger();
        }
    }
}
