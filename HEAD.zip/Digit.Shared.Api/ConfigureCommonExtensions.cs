﻿using Digit.Shared.Api.ErrorHandling;
using Digit.Shared.Api.Security;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Digit.Shared.Api
{
    public static class ConfigureCommonExtensions
    {
        public static void ConfigureCommonMiddleWare(this IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory,
            string swaggerEndPointUrl, string swaggerEndpointName)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint(swaggerEndPointUrl, swaggerEndpointName);
                    c.RoutePrefix = string.Empty;
                });
            }

            app.UseSerilogRequestLogging();

            app.ConfigureExceptionHandler(loggerFactory);

            app.UseMiddleware<RateLimiterMiddleware>();

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UserCorsPolicy();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health");
                endpoints.MapControllers();
            });
        }
    }
}
