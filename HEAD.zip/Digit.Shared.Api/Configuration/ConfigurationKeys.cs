﻿namespace Digit.Shared.Api.Configuration
{
    public static class ConfigurationKeys
    {
        public const string ApplicationInsightsInstrumentationKey = "ApplicationInsights:InstrumentationKey";
        public const string SqlConnectionStringName = "SqlServer";
        public const string BlobStorageConnectionStringName = "AzureBlobStorage";
        public const string ServiceBusConnectionStringName = "ServiceBus";
    }
}
