﻿using System;
using Digit.Shared.Data;
using Microsoft.Extensions.Configuration;

namespace Digit.Shared.Api.Configuration
{
    public class DigitConfigurationProvider : ConfigurationProvider
    {
        private DigitConfigurationSource Source { get; }

        public DigitConfigurationProvider(DigitConfigurationSource source)
        {
            Source = source;
        }

        public override void Load()
        {
            var settings = DigitContext.GetConfigurationSettings(Source.ConnectionString, Source.Module);

            foreach (var setting in settings)
            {
                Set(setting.Key, setting.Value);
            }
        }
    }

    public class DigitConfigurationOptions
    {
        public string ConnectionString { get; set; }
        public string Module { get; set; }
    }

    public class DigitConfigurationSource : IConfigurationSource
    {
        public string Module { get; }
        public string ConnectionString { get; }
        public DigitConfigurationSource(DigitConfigurationOptions options)
        {
            Module = options.Module;
            ConnectionString = options.ConnectionString;
        }

        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new DigitConfigurationProvider(this);
        }

    }

    public static class DigitConfigurationExtensions
    {
        public static IConfigurationBuilder AddDigitConfiguration(this IConfigurationBuilder configuration, Action<DigitConfigurationOptions> options)
        {
            _ = options ?? throw new ArgumentNullException(nameof(options));
            var digitConfigurationOptions = new DigitConfigurationOptions();
            options(digitConfigurationOptions);
            configuration.Add(new DigitConfigurationSource(digitConfigurationOptions));
            return configuration;
        }
    }
}
