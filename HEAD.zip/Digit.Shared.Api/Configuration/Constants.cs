﻿namespace Digit.Shared.Api.Configuration
{
    public static class Constants
    {
        public const string ConfigFileName = "appsettings.json";
        public const string EmailBrokerQueueName ="mail";
    }
}
