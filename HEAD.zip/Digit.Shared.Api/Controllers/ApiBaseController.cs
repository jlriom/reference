﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Digit.Shared.Api.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    public abstract class ApiBaseController<T> : ControllerBase where T: ControllerBase
    {
        protected ILogger<T> Logger;
        protected ApiBaseController(ILogger<T> logger)
        {
            Logger = logger;
        }
    }
}
