﻿using System;
using AutoMapper;
using Digit.Shared.Api.Configuration;
using Digit.Shared.Api.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;

namespace Digit.Shared.Api
{
    public static class ConfigureCommonServicesExtensions
    {

        public static void AddCommonServices(this IServiceCollection services, IConfiguration configuration, int mayorVersion, int minorVersion, params Type[] autoMapReferenceTypes)
        {
            services.AddSingleton(Log.Logger);
            services.AddApplicationInsightsTelemetry(configuration.GetValue<string>(ConfigurationKeys.ApplicationInsightsInstrumentationKey));
            services.AddMemoryCache();
            services.AddCorsPolicy();
            services.AddHealthChecks()
                .AddSqlServer(
                    configuration.GetConnectionString(ConfigurationKeys.SqlConnectionStringName))
                .AddAzureBlobStorage(
                    configuration.GetConnectionString(ConfigurationKeys.BlobStorageConnectionStringName))
                .AddAzureServiceBusQueue(
                    configuration.GetConnectionString(ConfigurationKeys.ServiceBusConnectionStringName), 
                    Constants.EmailBrokerQueueName);
            services.AddAutoMapper(autoMapReferenceTypes);
            services.AddControllers();
            services.AddApiVersioning(options =>
            {
                options.DefaultApiVersion = new ApiVersion(mayorVersion, minorVersion);
                options.AssumeDefaultVersionWhenUnspecified = true;
                options.ReportApiVersions = true;
            });
            services.AddSwaggerGen();
        }
    }
}
