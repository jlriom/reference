﻿using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.Extensions.DependencyInjection;

namespace Digit.Shared.Api.Security
{
    public static class CorsExtensions
    {
        private static readonly string CorsPolicyName = "CorsPolicyName";

        public static void AddCorsPolicy(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddCors(SetupCorsAction());
        }

        public static void UserCorsPolicy(this IApplicationBuilder app)
        {
            app.UseCors(CorsPolicyName);
        }

        private static Action<CorsOptions> SetupCorsAction()
        {
            return options =>
            {
                options.AddPolicy(name: CorsPolicyName,
                    builder =>
                    {
                        builder
                            .AllowAnyOrigin()
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            };
        }
    }
}
