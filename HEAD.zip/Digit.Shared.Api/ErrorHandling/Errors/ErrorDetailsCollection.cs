﻿using Common.Core;
using System.Collections.Generic;


namespace Digit.Shared.Api.ErrorHandling.Errors
{
    public class ErrorDetailsCollection
    {

        public IEnumerable<string> Errors { get; }

        public ErrorDetailsCollection()
        {
            Errors = new List<string>();
        }

        public ErrorDetailsCollection(IEnumerable<string> errors)
        {
            Errors = errors;
        }

        public override string ToString()
        {
            return this.Serialize();
        }
    }
}
