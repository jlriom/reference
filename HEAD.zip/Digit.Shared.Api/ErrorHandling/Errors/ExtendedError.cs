﻿using Microsoft.AspNetCore.Http;
using System;
using System.Text.Json;

namespace Digit.Shared.Api.ErrorHandling.Errors
{
    public class ExtendedError: Error
    {
        public string UserName { get; }
        public string Url { get; }

        public ExtendedError(Error error, HttpContext context)
            : base(error)
        {
            UserName = context.User.Identity.IsAuthenticated ? context.User.Identity.Name : String.Empty;
            Url = context.Request.Path.ToString();
        }

        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
