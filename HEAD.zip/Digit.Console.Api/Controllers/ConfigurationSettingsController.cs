﻿using Common.Application.Cqs.Contracts;
using Digit.Console.Application.Queries;
using Digit.Console.Application.Queries.Dtos;
using Digit.Shared.Api.Controllers;
using Digit.Shared.Api.ErrorHandling.Errors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Digit.Console.Api.Controllers
{
    public class ConfigurationSettingsController : ApiBaseController<ConfigurationSettingsController>
    {
        public ConfigurationSettingsController(
            ILogger<ConfigurationSettingsController> logger) : base(logger)
        {
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(AppError),StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedAccessError), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(DomainError), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(NotFoundError), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(InternalServerError), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<ConfigurationSettingsDto>>> 
            Get([FromServices] IQueryDispatcher queryDispatcher)
            => Ok(await queryDispatcher.Dispatch(new GetConfigurationSettingsQuery()).ConfigureAwait(false));
    }
}
