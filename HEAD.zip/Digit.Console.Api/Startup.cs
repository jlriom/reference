using Common.Application.Cqs;
using Digit.Console.Application.QueryHandlers;
using Digit.Console.Core;
using Digit.Console.Infrastructure;
using Digit.Shared.Api;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Digit.Console.Api
{
    public class Startup
    {
        private const int MayorVersion = 1, MinorVersion = 0;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        private IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCommonServices(Configuration, MayorVersion, MinorVersion, typeof(QueryHandlersReference));
            services.AddCqsServices(typeof(QueryHandlersReference));

            services.AddScoped<IConfigurationSettingsService, ConfigurationSettingsService>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            app.ConfigureCommonMiddleWare(env, loggerFactory, $"/swagger/v{MayorVersion}/swagger.json", typeof(Startup).Assembly.GetName().Name);
        }
    }
}
