﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Digit.Console.Core
{
    public interface IConfigurationSettingsService
    {
        Task<List<IConfigurationSection>> GetConfigurationSettings();
    }
}
