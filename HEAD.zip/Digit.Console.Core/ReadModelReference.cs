﻿namespace Digit.Console.Core
{
    public class ReadModelReference
    {
    }
}
